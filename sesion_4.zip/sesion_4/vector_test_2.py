import vector as vec

print vec.suma([1, 2], [3, 5, 7])