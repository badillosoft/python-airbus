def suma(a, b):
    n = len(a) if len(a) < len(b) else len(b)

    c = []

    for i in range(0, n):
        c.append(a[i] + b[i])

    return c

def resta(a, b):
    n = len(a) if len(a) < len(b) else len(b)

    c = []

    for i in range(0, n):
        c.append(a[i] - b[i])

    return c

def dot(a, b):
    n = len(a) if len(a) < len(b) else len(b)
    
    d = 0

    for i in range(0, n):
        d += a[i] * b[i]

    return d