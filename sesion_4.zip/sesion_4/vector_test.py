import vector

print vector.suma([1, 2, 3], [4, 3, 2])

print vector.resta([1, 2, 3], [3, 2, 1])