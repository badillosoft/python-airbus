from sklearn import tree

X = [
    [40, 40],
    [35, 60],
    [50, 50],
    [80, 70],
    [50, 30]
]

Y = [
    0,
    0,
    1,
    1,
    0
]

clf = tree.DecisionTreeClassifier()

clf.fit(X, Y)

print clf.predict([[60, 30]])