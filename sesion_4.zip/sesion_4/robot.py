from math import *
import turtle as t

class Robot:
    def __init__(self, x, y, a):
        self.x = x
        self.y = y
        self.a = a
        t.pu()
        t.lt(self.a)
        t.goto(self.x, self.y)
        t.pd()

    def mover(self):
        a = self.a * pi / 180
        self.x = self.x + cos(a)
        self.y = self.y + sin(a)
        t.goto(self.x, self.y)

    def girar_izq(self):
        self.a = self.a + 15
        t.lt(15)

    def girar_der(self):
        self.a = self.a - 15
        t.rt(15)

r = Robot(10, 10, 30)

import random
import time

while True:
    r.mover()
    if random.random() <= 0.5:
        r.girar_izq()
    else:
        r.girar_der()
    #time.sleep(0.1)

t.mainloop()