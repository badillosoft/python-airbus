from vector import suma

print suma([1, 5, 32], [3, 2])