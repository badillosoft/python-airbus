from vector import *

print suma([1, 2, 3], [4, 5, 6])
print resta([5, 6, 7], [1, 2, 3])