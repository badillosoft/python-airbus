import math
import pygame
import RPi.GPIO as GPIO
import time

class Robot:
	def __init__(self, x = 0, y = 0, a = 0, color = (255, 0, 0)):
		self.x = x
		self.y = y
		self.a = a
		self.color = color
		self.r = 10

	def setup_motor(self, in1, in2, in3, in4):
		self.motor = True
		self.p1 = in1
		self.p2 = in2
		self.p3 = in3
		self.p4 = in4
		
		self.delay_motor = 0.0032

		GPIO.setup(self.p1, GPIO.OUT)
		GPIO.setup(self.p2, GPIO.OUT)
		GPIO.setup(self.p3, GPIO.OUT)
		GPIO.setup(self.p4, GPIO.OUT)

	def setup_sensor(self, trig, echo):
		self.sensor = True
		self.trig = trig
		self.echo = echo
		self.delay_sensor = 0.00001

		GPIO.setup(self.trig, GPIO.OUT)
		GPIO.setup(self.echo, GPIO.IN)

		GPIO.output(self.trig, False)
		time.sleep(2)

	def forward_step(self, d = 1):
		self.x += d * math.cos(self.a)
		self.y += d * math.sin(self.a)

		# TODO: Implementar motor a pasos para dar un paso positivo
		if self.motor:
			GPIO.output(self.p1, True)
			GPIO.output(self.p2, True)
			GPIO.output(self.p3, False)
			GPIO.output(self.p4, False)
			time.sleep(self.delay_motor)
			GPIO.output(self.p1, False)
			GPIO.output(self.p2, True)
			GPIO.output(self.p3, True)
			GPIO.output(self.p4, False)
			time.sleep(self.delay_motor)
			GPIO.output(self.p1, False)
			GPIO.output(self.p2, False)
			GPIO.output(self.p3, True)
			GPIO.output(self.p4, True)
			time.sleep(self.delay_motor)
			GPIO.output(self.p1, True)
			GPIO.output(self.p2, False)
			GPIO.output(self.p3, False)
			GPIO.output(self.p4, True)
			time.sleep(self.delay_motor)


	def forward(self, steps = 1, d = 1):
		for i in range(steps):
			self.forward_step(d)

	def backward_step(self, d = 1):
		self.x -= d * math.cos(self.a)
		self.y -= d * math.sin(self.a)

		# TODO: Implementar motor a pasos para dar un paso negativo
		if self.motor:
			GPIO.output(self.p1, True)
			GPIO.output(self.p2, False)
			GPIO.output(self.p3, False)
			GPIO.output(self.p4, True)
			time.sleep(self.delay_motor)
			GPIO.output(self.p1, False)
			GPIO.output(self.p2, False)
			GPIO.output(self.p3, True)
			GPIO.output(self.p4, True)
			time.sleep(self.delay_motor)
			GPIO.output(self.p1, False)
			GPIO.output(self.p2, True)
			GPIO.output(self.p3, True)
			GPIO.output(self.p4, False)
			time.sleep(self.delay_motor)
			GPIO.output(self.p1, True)
			GPIO.output(self.p2, True)
			GPIO.output(self.p3, False)
			GPIO.output(self.p4, False)
			time.sleep(self.delay_motor)
			
			

	def backward(self, steps = 1, d = 1):
		for i in range(steps):
			self.backward_step(d)

	def turn_left(self, da = math.pi / 256):
		self.a += da

	def turn_right(self, da = math.pi / 256):
		self.a -= da

	def distance(self):
		d = 0
		# TODO: Implementar el sensor de distancia
		if self.sensor:
			GPIO.output(self.trig, True)
			time.sleep(self.delay_sensor)
			GPIO.output(self.trig, False)

			pulse_start = pulse_end = 0

			while GPIO.input(self.echo) == 0:
				pulse_start = time.time()
			
			while GPIO.input(self.echo) == 1:
				pulse_end = time.time()

			pulse_duration = pulse_end - pulse_start
			
			d = pulse_duration * 17150

		return d

	def draw(self, surface):
		x0 = self.x
		x1 = self.x + self.r * math.cos(self.a)
		x2 = self.x + self.r * math.cos(self.a + 2 * math.pi / 3)
		x3 = self.x + self.r * math.cos(self.a - 2 * math.pi / 3)

		y0 = self.y
		y1 = self.y + self.r * math.sin(self.a)
		y2 = self.y + self.r * math.sin(self.a + 2 * math.pi / 3)
		y3 = self.y + self.r * math.sin(self.a - 2 * math.pi / 3)

		pygame.draw.line(surface, self.color, (x1, y1), (x2, y2))
		pygame.draw.line(surface, self.color, (x2, y2), (x0, y0))
		pygame.draw.line(surface, self.color, (x0, y0), (x3, y3))
		pygame.draw.line(surface, self.color, (x3, y3), (x1, y1))