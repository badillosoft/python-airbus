import matplotlib.pyplot as plt

plt.plot([1, 2, 3], [1, 4, 9], "r")

plt.show()

