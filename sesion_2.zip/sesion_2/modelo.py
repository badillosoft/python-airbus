f = open("datos.csv", "r")

for linea in f:
    s = linea.split(",")

    t = float(s[0])
    x = float(s[1])
    y = float(s[2])

    if t >= 1 and t <= 2:
        print t, x, y, (x**2 + y**2)**0.5

f.close()