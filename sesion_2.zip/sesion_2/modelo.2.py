def linspace(a, b, n):
    # Delta es l diferencia entre dos numeros
    d = float(b - a) / (n - 1)

    # El arreglo de n numeros uniformemente distribuidos
    r = []

    # Agregamos a + 0 * d, a + 1 * d, ..., a + (n - 1) * d
    for i in range(0, n):
        r.append(a + i * d)

    return r

def x(t):
    return xo + vxo * t

def y(t):
    return yo + vyo * t - g * t**2 / 2.0

xo = 1
yo = 1
vxo = 5
vyo = 20
g = 9.81

f = open("datos.csv", "w")

for t in linspace(0, 4, 30):
    f.write("%.4f,%.4f,%.4f\n" % (t, x(t), y(t)))
    #print "%.4f,%.4f,%.4f" % (t, x(t), y(t))

f.close()