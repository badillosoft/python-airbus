def ylin(x, xi, yi, xf, yf):
    return yf + (yf - yi) / float(xf - xi) * (x - xi)

def interpol(points, x):
    n = len(points)

    for i in range(0, n - 1):
        xi, yi = points[i]
        xf, yf = points[i + 1]

        if x <= xi or (x >= xi and x < xf):
            break

    return ylin(x, xi, yi, xf, yf)

points = [(-5, 4), (-3, 8), (0, 4), (1, 3), (6, -7)]

f = open("data.csv", "w")

x = -10
while x <= 10:
    y = interpol(points, x)

    f.write("%f, %f\n" % (x, y))

    x += 0.5

f.close()
