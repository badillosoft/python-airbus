import pygame, math

pygame.init()

screen = pygame.display.set_mode((800, 600))

x, y, r, a = 400, 300, 10, 0

while True:
    for evt in pygame.event.get():
        if evt.type == pygame.QUIT:
            exit()

    # Logica de juego
    a += math.pi / 128
    x += 0.5

    x1 = x + r * math.cos(a)
    y1 = y + r * math.sin(a)

    x2 = x + r * math.cos(a + 2 * math.pi / 3)
    y2 = y + r * math.sin(a + 2 * math.pi / 3)

    x3 = x + r * math.cos(a - 2 * math.pi / 3)
    y3 = y + r * math.sin(a - 2 * math.pi / 3)

    screen.fill((177, 220, 224))

    # Logica de dibujo
    pygame.draw.line(screen, (255, 0, 0), (x1, y1), (x2, y2))
    pygame.draw.line(screen, (255, 0, 0), (x2, y2), (x, y))
    pygame.draw.line(screen, (255, 0, 0), (x, y), (x3, y3))
    pygame.draw.line(screen, (255, 0, 0), (x3, y3), (x1, y1))

    pygame.display.flip()
    pygame.time.delay(17)
