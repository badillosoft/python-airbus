def min_max(arr):
    min = arr[0]
    max = arr[0]

    for x in arr:
        if x < min:
            min = x

        if x > max:
            max = x

    return (min, max)

print min_max([1, 4, 3, 0, 2, 8, 5])