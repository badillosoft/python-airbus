import pygame, math

class Robot:
    def __init__(self, x, y, a):
        self.x = x
        self.y = y
        self.a = a
        self.r = 10

    def mover(self):
        self.x += 0.5 * math.cos(self.a)
        self.y += 0.5 * math.sin(self.a)

    def girar_izq(self):
        self.a -= math.pi / 64

    def girar_der(self):
        self.a += math.pi / 64

    def dibujar(self, screen):
        x = self.x
        y = self.y

        x1 = self.x + self.r * math.cos(self.a)
        y1 = self.y + self.r * math.sin(self.a)

        x2 = self.x + self.r * math.cos(self.a + 2 * math.pi / 3)
        y2 = self.y + self.r * math.sin(self.a + 2 * math.pi / 3)

        x3 = self.x + self.r * math.cos(self.a - 2 * math.pi / 3)
        y3 = self.y + self.r * math.sin(self.a - 2 * math.pi / 3)

        pygame.draw.line(screen, (255, 0, 0), (x1, y1), (x2, y2))
        pygame.draw.line(screen, (255, 0, 0), (x2, y2), (x, y))
        pygame.draw.line(screen, (255, 0, 0), (x, y), (x3, y3))
        pygame.draw.line(screen, (255, 0, 0), (x3, y3), (x1, y1))

pygame.init()

screen = pygame.display.set_mode((800, 600))

robot = Robot(400, 300, 0)
robot2 = Robot(400, 300, 0)

s = 0

while True:
    for evt in pygame.event.get():
        if evt.type == pygame.QUIT:
            exit()
        if evt.type == pygame.KEYDOWN:
            if evt.key == pygame.K_LEFT:
                #robot.girar_izq()
                s = 1
            elif evt.key == pygame.K_RIGHT:
                #robot.girar_der()
                s = 2
        if evt.type == pygame.KEYUP:
            s = 0

    # Logica de juego
    if s == 1:
        robot.girar_izq()
    elif s == 2:
        robot.girar_der()
    robot.mover()
    robot2.mover()
    
    screen.fill((177, 220, 224))

    # Logica de dibujo
    robot.dibujar(screen)
    robot2.dibujar(screen)

    pygame.display.flip()
    pygame.time.delay(17)
