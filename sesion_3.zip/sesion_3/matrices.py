def crea_matriz(n, m):
    mat = []

    for i in range(0, n):
        vec = []

        for j in range(0, m):
            vec.append(0)
        
        mat.append(vec)

    return mat

print crea_matriz(2, 2)
print crea_matriz(4, 3)

A = crea_matriz(4, 4)

for i in range(0, 4):
    A[i][i] = 1

print A