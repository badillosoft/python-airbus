from visual import *

b = box(size = (10, 0.1, 10))

s = sphere(pos = (0, 10, 0))

def x(t):
    return 0 + 5 * t

def y(t):
    return 0 + 10 * t - 9.81 * t ** 2 / 2

t = 0

while True:
    rate(100)

    s.pos = (x(t), y(t), 0)

    t += 0.01