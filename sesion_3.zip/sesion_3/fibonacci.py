f = [1, 1]

a = 1
b = 1
c = 2

for i in range(20):
    c = a + b
    a = b
    b = c

    f.append(c)

print f