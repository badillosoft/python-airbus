import math
import pygame

class Robot:
	def __init__(self, x = 0, y = 0, a = 0, color = (255, 0, 0)):
		self.x = x
		self.y = y
		self.a = a
		self.color = color
		self.r = 10

	def forward_step(self, d = 1):
		self.x += d * math.cos(self.a)
		self.y += d * math.sin(self.a)

		# TODO: Implementar motor a pasos para dar un paso positivo

	def forward(self, steps = 1, d = 1):
		for i in range(steps):
			self.forward_step(d)

	def backward_step(self, d = 1):
		self.x -= d * math.cos(self.a)
		self.y -= d * math.sin(self.a)

		# TODO: Implementar motor a pasos para dar un paso negativo

	def backward(self, steps = 1, d = 1):
		for i in range(steps):
			self.backward_step(d)

	def turn_left(self, da = math.pi / 256):
		self.a += da

	def turn_right(self, da = math.pi / 256):
		self.a -= da

	def distance(self):
		# TODO: Implementar el sensor de distancia 
		d = 0
		return d

	def draw(self, surface):
		x0 = self.x
		x1 = self.x + self.r * math.cos(self.a)
		x2 = self.x + self.r * math.cos(self.a + 2 * math.pi / 3)
		x3 = self.x + self.r * math.cos(self.a - 2 * math.pi / 3)

		y0 = self.y
		y1 = self.y + self.r * math.sin(self.a)
		y2 = self.y + self.r * math.sin(self.a + 2 * math.pi / 3)
		y3 = self.y + self.r * math.sin(self.a - 2 * math.pi / 3)

		pygame.draw.line(surface, self.color, (x1, y1), (x2, y2))
		pygame.draw.line(surface, self.color, (x2, y2), (x0, y0))
		pygame.draw.line(surface, self.color, (x0, y0), (x3, y3))
		pygame.draw.line(surface, self.color, (x3, y3), (x1, y1))