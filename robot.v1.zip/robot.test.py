from robot import Robot
import pygame

pygame.init()

screen = pygame.display.set_mode((800, 600))

r = Robot(400, 300)

state_turn = "STOP"
state_move = "STOP"

while True:
	# Controlamos los eventos de pygame
	for evt in pygame.event.get():
		if evt.type == pygame.QUIT:
			exit()

		if evt.type == pygame.KEYDOWN:
			if evt.key == pygame.K_LEFT:
				state_turn = "LEFT"
			elif evt.key == pygame.K_RIGHT:
				state_turn = "RIGHT"
			elif evt.key == pygame.K_UP:
				state_move = "FORWARD"
			elif evt.key == pygame.K_DOWN:
				state_move = "BACKWARD"
		
		if evt.type == pygame.KEYUP:
			if evt.key == pygame.K_LEFT or evt.key == pygame.K_RIGHT:
				state_turn = "STOP"
			if evt.key == pygame.K_UP or evt.key == pygame.K_DOWN:
				state_move = "STOP"


	# Logica de Juego
	if state_turn == "LEFT":
		r.turn_left()
	elif state_turn == "RIGHT":
		r.turn_right()

	if state_move == "FORWARD":
		r.forward()
	elif state_move == "BACKWARD":
		r.backward()

	# Logica Dibujo

	# Fondo de pantalla gris
	screen.fill((127, 127, 127))

	# Dibujar al robot
	r.draw(screen)

	# Intercambiar el buffer de dibujo
	pygame.display.flip()

	# Hacemos una pausa para mantener 60fps
	pygame.time.delay(17)