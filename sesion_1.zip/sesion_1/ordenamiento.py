def busca_menor(A):
    x = A[0]

    for y in A:
        if y < x:
            x = y

    return x

def ordena(A):
    B = []

    while len(A) > 0:
        x = busca_menor(A)
        B.append(x)
        A.remove(x)

    return B

print ordena([4, 3, 5, 6, 2, 6, 8, 1])