frutas = ["manzana", "pera"]

print frutas

# agrega mngo al final
frutas.append("mango")

print frutas

# imprimimos la posicion 1 del arreglo
print frutas[1]

# borramos el elemento en la posicion 1
# y lo devolvemos para imprimir
print frutas.pop(1)

print frutas # [manzana, mango] esto es un comentario

print frutas.count("pera")

frutas.append("manzana")

print frutas

print frutas.count("manzana")

frutas.remove("manzana")

print frutas

frutas.insert(1, "pera")

print frutas

del frutas[0]

print frutas